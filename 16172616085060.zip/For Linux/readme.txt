XP-58 is for 58mm paper width printer;
XP-76 is for 76mm paper width printer;
XP-80 is for 80mm paper width printer.