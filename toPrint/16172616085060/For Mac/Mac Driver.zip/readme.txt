1. Double click pkg file to install the driver,
2. After installed the pkg file, then add a printer at setting, and select the correct ppd file for the printer.

POS-58.ppd is for 58mm paper width printer;
POS-76.ppd is for 76mm paper width printer;
POS-80.ppd is for 80mm paper width printer.